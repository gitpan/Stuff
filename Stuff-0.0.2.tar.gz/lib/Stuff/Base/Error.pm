package Stuff::Base::Error;

use Stuff -Exception;

1;
